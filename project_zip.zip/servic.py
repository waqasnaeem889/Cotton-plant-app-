import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, BatchNormalization, Dropout
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import LearningRateScheduler, EarlyStopping
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import numpy as np
import matplotlib.pyplot as plt
from flask import json


def predict_cotton_disease(image_path, model):
    class_indices = {0: 'Aphid', 1: 'Army Worm', 2: 'Bacterial Blight', 3: 'Fresh Cotton Plant', 4: 'Powdery Mildew', 5: 'Target Spot'}
    # Load and preprocess the image
    # img = load_img(image_path, target_size=(224, 224))
    img = load_img("uploads/data.jpg", target_size=(128, 128))
    img_array = img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
#    img_array /= 255.0

    # Make predictions
    prediction = model.predict(img_array)
    print("======================================================================================================================================")
    print(prediction)
    predicted_class_index = np.argmax(prediction)
    print("======================================================================================================================================")
    print(predicted_class_index)
#    predicted_class = class_indices[predicted_class_index]

    return predicted_class_index


def predict(img_pth):
    model = load_model('NewModelInshaAllahChalJayga2.h5')
    data = predict_cotton_disease(img_pth, model);
    return data