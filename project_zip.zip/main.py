# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
from flask import Flask, request
import servic;
import requests
from PIL import Image
from io import BytesIO

app = Flask(__name__)

@app.route("/")
def hello_world():
    startup = {"code": 1, "msg": "App running fine"}
    return startup

@app.route("/predict_deases", methods=['POST'])
def getData():
    body = request.get_json()
    image_path = body['image']
    response = requests.get(image_path)
    if response.status_code == 200:
        # Open the image using PIL
        image = Image.open(BytesIO(response.content))
        new_image = image.resize((128, 128))
        # Save the image as JPG
        bw_image = image.convert('L')
        bw_image.save("uploads/data.jpg")

    image_path = "uploads/data.jpg"

    class_indices = {0: 'Aphid', 1: 'Army Worm', 2: 'Bacterial Blight', 3: 'Healthy', 4: 'Powdery Mildew', 5: 'Target Spot', 6: 'Unknown'}

    data = servic.predict(image_path)

    res = {
	'id': str(data),
	'name': class_indices[data]
	}
    
    return res


# main driver function
if __name__ == '__main__':
    app.run(port=3001, host="0.0.0.0")